<?php
/**
 * WooCommerce Single Product Page — SaleOnBeauty
 * - Dedicated Ad Campaign Landing Page for Beauty Milk
 * - Premium Luxury Custom Landing Page for ALL other products (100% Dynamic)
 */

get_header();

if (have_posts()) { the_post(); }

$pid     = get_the_ID();
$product = wc_get_product($pid);
if (!$product) { get_footer(); exit; }

// ── Check if this is the Beauty Milk ad landing product ──
$product_slug   = $product->get_slug();
$post_name      = get_post_field('post_name', $pid);
$product_title  = get_the_title($pid);

$is_beauty_milk = (
    $pid == 15 || 
    $product_slug === 'beauty-milk' || 
    $product_slug === 'beauty-milk-skin-tone-upgrade-drink' || 
    stripos($product_slug, 'beauty-milk') !== false || 
    stripos($post_name, 'beauty-milk') !== false ||
    stripos($product_title, 'Beauty Milk') !== false
);

// ── Core product data ──
$price        = $product->get_price();
$reg_price    = $product->get_regular_price();
$is_on_sale   = $product->is_on_sale();
$in_stock     = $product->is_in_stock();
$stock_qty    = $product->get_stock_quantity();
$cart_url     = $product->add_to_cart_url();
$price_num    = floatval($price);
$reg_num      = floatval($reg_price);
$discount_pct = ($is_on_sale && $reg_num > 0 && $price_num > 0)
    ? round((($reg_num - $price_num) / $reg_num) * 100) : 0;
$save_amount  = ($is_on_sale && $reg_num > $price_num) ? ($reg_num - $price_num) : 0;

// ── Custom meta ──
$ingr_raw    = get_post_meta($pid, 'sob_ingredients', true);
$how_to_use  = get_post_meta($pid, 'sob_how_to_use', true);
$result_days = get_post_meta($pid, 'sob_result_days', true);
$guarantee   = get_post_meta($pid, 'sob_guarantee', true);
$tagline     = get_post_meta($pid, 'sob_tagline', true);
$video_id    = get_post_meta($pid, 'sob_product_video_id', true);
$rev_video1  = get_post_meta($pid, 'sob_review_video_1', true);
$rev_video2  = get_post_meta($pid, 'sob_review_video_2', true);
$product_name = get_the_title();

// ── Ingredient icon map ──
$ingr_icons = [
    'Glutathione'    => '✨',
    'Collagen'       => '💗',
    'Ashwagandha'    => '🌿',
    'Dead Sea Salt'  => '🧂',
    'Rose Extract'   => '🌹',
    'Papaya'         => '🍈',
    'Lemon'          => '🍋',
    'Coffee'         => '☕',
    'Rice'           => '🌾',
    'Snail Extract'  => '🐌',
    'Centella'       => '🍃',
    'Hyaluronic Acid'=> '💧',
    'Niacinamide'    => '⭐',
    'Vitamin C'      => '🍊',
    'SPF'            => '☀️',
    'Sunscreen'      => '☀️',
];
function sob_ingr_icon($name, $map) {
    foreach ($map as $key => $icon) {
        if (stripos($name, $key) !== false) return $icon;
    }
    return '🌟';
}

// ── Category emoji for no-image fallback ──
$cats = get_the_terms($pid, 'product_cat');
$cat_emoji = '💄';
if ($cats && !is_wp_error($cats)) {
    $slug = $cats[0]->slug;
    $cat_emojis = ['whitening-juice'=>'🥤','whitening-soap'=>'🧼','body-care'=>'🛁','skin-care'=>'✨'];
    $cat_emoji = $cat_emojis[$slug] ?? '💄';
}

// ── Capture Product Video HTML ──
ob_start();
if ($video_id) :
?>
<!-- ===== PRODUCT VIDEO ===== -->
<section class="spd-video-section" id="spd-product-video">
  <div class="container">
    <div class="spd-product-video-wrap">
      <div class="spd-product-video-inner">
        <div class="pv-corner pv-tl"></div>
        <div class="pv-corner pv-tr"></div>
        <div class="pv-corner pv-bl"></div>
        <div class="pv-corner pv-br"></div>
        <div class="spd-product-iframe-box">
          <iframe
            src="https://www.youtube.com/embed/<?php echo esc_attr($video_id); ?>?rel=0&modestbranding=1"
            title="<?php echo esc_attr($product_name); ?> — Product Video"
            frameborder="0"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowfullscreen loading="lazy"
          ></iframe>
        </div>
      </div>

      <!-- Side panel — dynamic ingredients -->
      <?php if ($ingr_raw) :
        $vid_ingr = array_slice(array_map('trim', explode(',', $ingr_raw)), 0, 3);
        $vside_descs = [
            'Glutathione'     => 'ত্বককে Bright ও Clear করে',
            'Collagen'        => 'ত্বককে Firm ও Youthful রাখে',
            'Ashwagandha'     => 'Healthy skin ও Wellness support',
            'Dead Sea Salt'   => 'Dead skin cells দূর করে',
            'Rose Extract'    => 'ত্বককে Soft ও Fragrant করে',
            'Centella'        => 'Soothing ও Calming effect দেয়',
            'Hyaluronic Acid' => 'ত্বকে Deep moisture দেয়',
            'Niacinamide'     => 'Skin tone even করে',
        ];
      ?>
      <div class="spd-video-side">
        <?php foreach ($vid_ingr as $ingr) : if (empty($ingr)) continue;
          $vicon = sob_ingr_icon($ingr, $ingr_icons);
          $vdesc = '';
          foreach ($vside_descs as $k => $d) {
              if (stripos($ingr, $k) !== false) { $vdesc = $d; break; }
          }
          $vdesc = $vdesc ?: 'Premium ingredient';
        ?>
          <div class="vside-item">
            <div class="vside-icon"><?php echo $vicon; ?></div>
            <div>
              <h4><?php echo esc_html($ingr); ?></h4>
              <p><?php echo esc_html($vdesc); ?></p>
            </div>
          </div>
        <?php endforeach; ?>
        <?php if ($result_days) : ?>
          <div class="vside-item">
            <div class="vside-icon">🛡️</div>
            <div>
              <h4><?php echo esc_html($result_days); ?> দিনে Result</h4>
              <p>না হলে ১০০% Money-Back</p>
            </div>
          </div>
        <?php endif; ?>
        <a href="<?php echo esc_url($cart_url); ?>" class="vside-btn">🛒 এখনই Order করুন</a>
      </div>
      <?php endif; ?>
    </div>
  </div>
</section>
<?php
endif;
$product_video_html = ob_get_clean();

?>

<main id="product-main" class="<?php echo $is_beauty_milk ? 'is-beauty-milk' : 'is-general-product'; ?>" style="padding-top: 24px; background: #ffffff; min-height: 100vh;">

<!-- ===== PRODUCT HERO ===== -->
<section class="spd-hero" id="spd-hero">
  <div class="container">
    <div class="spd-grid">

      <!-- LEFT: Image -->
      <div class="spd-image-col" id="spd-image-col">

        <!-- ===== PREMIUM IMAGE GALLERY ===== -->
        <?php
        // Build gallery image list (main + gallery)
        $gallery_images = [];
        if (has_post_thumbnail()) {
            $gallery_images[] = [
                'full'   => get_the_post_thumbnail_url($pid, 'full'),
                'large'  => get_the_post_thumbnail_url($pid, 'large'),
                'thumb'  => get_the_post_thumbnail_url($pid, 'thumbnail'),
                'alt'    => get_post_meta(get_post_thumbnail_id($pid), '_wp_attachment_image_alt', true) ?: $product_name,
            ];
        }
        $gal_ids = $product->get_gallery_image_ids();
        foreach ($gal_ids as $gid) {
            $gallery_images[] = [
                'full'  => wp_get_attachment_image_url($gid, 'full'),
                'large' => wp_get_attachment_image_url($gid, 'large'),
                'thumb' => wp_get_attachment_image_url($gid, 'thumbnail'),
                'alt'   => get_post_meta($gid, '_wp_attachment_image_alt', true) ?: $product_name,
            ];
        }
        $has_gallery = count($gallery_images) > 1;
        ?>

        <?php if (!empty($gallery_images)) : ?>
        <!-- Gallery wrapper -->
        <div class="spd-gallery" id="spd-gallery" data-total="<?php echo count($gallery_images); ?>">

          <!-- Sale + Best Seller badges -->
          <?php if ($discount_pct > 0) : ?>
            <div class="spd-badge-sale" style="position:absolute;top:12px;left:12px;z-index:10;">-<?php echo $discount_pct; ?>%</div>
          <?php endif; ?>
          <div class="spd-badge-top" style="position:absolute;top:12px;right:12px;z-index:10;">✦ বেস্ট সেলার</div>

          <?php if ($has_gallery) : ?>
          <button class="gallery-arrow gallery-arrow--prev" onclick="spdGallery.prev()" aria-label="Previous image">&#8249;</button>
          <button class="gallery-arrow gallery-arrow--next" onclick="spdGallery.next()" aria-label="Next image">&#8250;</button>
          <?php endif; ?>

          <!-- Main image -->
          <div class="spd-gallery-main" id="spd-gallery-main">
            <img
              src="<?php echo esc_url($gallery_images[0]['large']); ?>"
              alt="<?php echo esc_attr($gallery_images[0]['alt']); ?>"
              class="spd-main-img"
              id="spd-main-img"
              onclick="spdGallery.openLightbox(0)"
              style="cursor: zoom-in;"
            >
            <?php if ($has_gallery) : ?>
            <div class="gallery-counter" id="gallery-counter">1 / <?php echo count($gallery_images); ?></div>
            <?php endif; ?>
            <div class="gallery-zoom-hint">🔍 জুম করতে ক্লিক করুন</div>

            <!-- Guarantee badge overlaid on image bottom -->
            <div class="spd-guarantee-badge">
              <span class="gb-icon">🛡️</span>
              <div>
                <strong><?php echo ($is_beauty_milk && $result_days) ? esc_html($result_days) . ' দিন' : '১০০% অরিজিনাল'; ?></strong>
                <span><?php echo ($is_beauty_milk && $result_days) ? 'ব্যবহার করুন' : 'Authentic Guarantee'; ?></span>
              </div>
              <div class="gb-divider"></div>
              <div>
                <strong><?php echo ($is_beauty_milk) ? 'কাজ না করলে' : 'ক্যাশ অন ডেলিভারি'; ?></strong>
                <span><?php echo ($is_beauty_milk) ? '১০০% Refund' : 'পণ্য দেখে পেমেন্ট'; ?></span>
              </div>
            </div>
          </div>

          <!-- Thumbnails strip -->
          <?php if ($has_gallery) : ?>
          <div class="spd-thumbs-row" id="spd-thumbs-row">
            <?php foreach ($gallery_images as $i => $img) : ?>
              <div class="spd-thumb <?php echo $i === 0 ? 'active' : ''; ?>"
                   onclick="spdGallery.goTo(<?php echo $i; ?>)"
                   title="Image <?php echo $i + 1; ?>">
                <img src="<?php echo esc_url($img['thumb']); ?>" alt="<?php echo esc_attr($img['alt']); ?>" loading="lazy">
              </div>
            <?php endforeach; ?>
          </div>
          <?php endif; ?>
        </div>

        <!-- Lightbox -->
        <div class="spd-lightbox" id="spd-lightbox" onclick="spdGallery.closeLightbox()">
          <button class="lb-close" onclick="spdGallery.closeLightbox()">✕</button>
          <?php if ($has_gallery) : ?>
          <button class="lb-arrow lb-arrow--prev" onclick="event.stopPropagation(); spdGallery.lbPrev()">&#8249;</button>
          <button class="lb-arrow lb-arrow--next" onclick="event.stopPropagation(); spdGallery.lbNext()">&#8250;</button>
          <?php endif; ?>
          <div class="lb-img-wrap" onclick="event.stopPropagation()">
            <img src="" alt="" id="lb-img" class="lb-img">
          </div>
          <?php if ($has_gallery) : ?>
          <div class="lb-counter" id="lb-counter">1 / <?php echo count($gallery_images); ?></div>
          <?php endif; ?>
        </div>

        <!-- Gallery JS data -->
        <script>
        var spdGalleryImages = <?php echo json_encode(array_map(function($img) {
            return ['large' => $img['large'], 'full' => $img['full'], 'alt' => $img['alt']];
        }, $gallery_images)); ?>;
        </script>

        <?php else : ?>
        <!-- No image fallback -->
        <div class="spd-no-img">
          <div class="spd-no-img-inner">
            <span><?php echo $cat_emoji; ?></span>
            <p><?php echo esc_html($product_name); ?></p>
          </div>
        </div>
        <?php endif; ?>

        <!-- Trust badges -->
        <div class="spd-trust-row">
          <div class="trust-badge"><span>✓</span> ১০০% অরিজিনাল</div>
          <div class="trust-badge"><span>🚚</span> ফ্রি ডেলিভারি</div>
          <div class="trust-badge"><span>🔄</span> ইজি রিটার্ন</div>
          <div class="trust-badge"><span>⭐</span> ৪.৯/৫</div>
        </div>

      </div>

      <!-- RIGHT: Info -->
      <div class="spd-info-col" id="spd-info-col">

        <?php if ($is_beauty_milk) : ?>
          <!-- Headline (Strictly 1 Line across all devices) -->
          <h1 class="spd-landing-headline" id="spd-landing-headline">
            মাত্র ২১ দিনেই আপনার <span class="spd-gold-gradient">Skin Tone Upgrade</span> করুন 🌟
          </h1>

          <!-- Sub-headline (Strictly 2 Lines across all devices) -->
          <div class="spd-landing-subheadline" id="spd-landing-subheadline">
            <span class="sub-line sub-line-1">প্রতিদিন ১ বার Beauty Milk পান করুন, ২১ দিনে Skin Tone পরিবর্তন করুন।</span>
            <span class="sub-line sub-line-2">২১ দিনে প্রত্যাশিত পরিবর্তন না হলে ১০০% Money-Back Guarantee।</span>
          </div>
        <?php else : ?>
          <h1 class="spd-title" style="margin-bottom: 14px;"><?php echo esc_html($product_name); ?></h1>

          <!-- Rating -->
          <div class="spd-rating">
            <span class="stars-lg">★★★★★</span>
            <span class="rating-num">4.9</span>
            <span class="rating-count">(১২০+ ভেরিফায়েড রিভিউ)</span>
          </div>

          <!-- Price Row -->
          <div class="spd-price-box">
            <span class="spd-current-price">৳<?php echo number_format($price_num, 0); ?></span>
            <?php if ($is_on_sale && $reg_num > 0) : ?>
              <del class="spd-old-price">৳<?php echo number_format($reg_num, 0); ?></del>
              <?php if ($save_amount > 0) : ?>
                <span class="spd-save-badge">সাশ্রয় ৳<?php echo number_format($save_amount, 0); ?></span>
              <?php endif; ?>
            <?php endif; ?>
          </div>

          <!-- Tagline or Short Description -->
          <?php if ($tagline) : ?>
            <div class="spd-tagline">
              <?php echo esc_html($tagline); ?>
            </div>
          <?php elseif ($short_desc = $product->get_short_description()) : ?>
            <div class="spd-short-desc">
              <?php echo wp_kses_post($short_desc); ?>
            </div>
          <?php endif; ?>

          <!-- Stock Status -->
          <div class="spd-stock-row">
            <?php if ($in_stock) : ?>
              <span class="stock-in">✓ স্টকে আছে</span>
            <?php else : ?>
              <span class="stock-out">✗ স্টক শেষ</span>
            <?php endif; ?>
          </div>
        <?php endif; ?>

        <!-- Mobile Video Injection -->
        <?php if ($is_beauty_milk && !empty($product_video_html)) : ?>
        <div class="spd-video-mobile-only">
          <?php echo $product_video_html; ?>
        </div>
        <?php endif; ?>

        <!-- Order buttons (Order Now only, NO Add to Cart) -->
        <div class="spd-order-box">
          <a href="#spd-checkout" class="spd-order-btn" style="width:100%; border:none; cursor:pointer; text-decoration:none; display:flex; align-items:center; justify-content:center;">
            🛒 অর্ডার করুন
          </a>
        </div>

        <!-- Delivery -->
        <div class="spd-delivery">
          <div class="dlv-item"><span>🚚</span> ঢাকায় ২৪-৪৮ ঘন্টায়, সারা বাংলাদেশে ১–৩ দিনে ডেলিভারি</div>
          <div class="dlv-item"><span>🛡️</span> ১০০% আসল ও অরিজিনাল পণ্য</div>
          <div class="dlv-item"><span>🔄</span> <?php echo $guarantee ? esc_html($guarantee) : '১০০% মানি-ব্যাক গ্যারান্টি'; ?></div>
        </div>

      </div><!-- end info col -->
    </div><!-- end grid -->
  </div>
</section>

<!-- ===== PRODUCT VIDEO DESKTOP ===== -->
<div class="spd-video-desktop-only">
  <?php echo $product_video_html ?? ''; ?>
</div>

<!-- ===== HOW IT WORKS (only if ingredients set) ===== -->
<?php if ($ingr_raw) :
  $ingr_cards = array_map('trim', explode(',', $ingr_raw));
  $ingr_details = [
      'Glutathione'     => 'ত্বককে আরও <strong>Bright & Clear</strong> দেখাতে সাহায্য করে। Melanin production কমিয়ে skin tone উন্নত করে।',
      'Collagen'        => 'ত্বককে <strong>Smooth, Firm & Youthful-looking</strong> রাখতে সহায়তা করে। Skin elasticity বাড়ায়।',
      'Ashwagandha'     => 'Overall <strong>wellness</strong> ও <strong>healthy-looking skin</strong> support করে। Stress কমিয়ে skin glow আনে।',
      'Dead Sea Salt'   => '<strong>Dead skin cells</strong> দূর করে। ত্বককে Soft, Smooth ও Refreshed অনুভব করায়।',
      'Rose Extract'    => 'ত্বককে <strong>Soft ও Hydrated</strong> রাখে। Natural fragrance ও সৌন্দর্য বৃদ্ধি করে।',
      'Centella'        => '<strong>Soothing ও Calming</strong> effect দেয়। Sensitive skin এর জন্য উপযুক্ত।',
      'Hyaluronic Acid' => 'ত্বকে <strong>Deep moisture</strong> দেয়। Skin plump ও hydrated রাখে।',
      'Niacinamide'     => 'Skin tone <strong>even ও bright</strong> করে। Dark spots কমাতে সাহায্য করে।',
  ];
?>
<section class="spd-how-section" id="spd-how">
  <div class="container">
    <span class="gold-badge">How It Works</span>
    <h2 class="section-title"><?php echo esc_html($product_name); ?> কীভাবে কাজ করে? ✨</h2>
    <div class="section-divider"></div>
    <div class="spd-how-grid">
      <?php foreach ($ingr_cards as $ingr) : if (empty($ingr)) continue;
        $icon   = sob_ingr_icon($ingr, $ingr_icons);
        $detail = '';
        foreach ($ingr_details as $k => $d) {
            if (stripos($ingr, $k) !== false) { $detail = $d; break; }
        }
        $detail = $detail ?: esc_html($ingr) . ' আপনার ত্বকের সৌন্দর্য বৃদ্ধিতে সাহায্য করে।';
      ?>
        <div class="how-card">
          <div class="how-icon"><?php echo $icon; ?></div>
          <h3><?php echo esc_html($ingr); ?></h3>
          <p><?php echo wp_kses_post($detail); ?></p>
        </div>
      <?php endforeach; ?>
    </div>
    <?php if (count($ingr_cards) > 1) : ?>
    <div class="spd-combined">
      <div class="combined-icon">💎</div>
      <div>
        <h3>একসাথে কীভাবে কাজ করে?</h3>
        <p><?php echo esc_html(implode(' + ', $ingr_cards)); ?> একসাথে আপনার daily beauty routine-এ যোগ করে ত্বককে আরও <strong>উজ্জ্বল, ফ্রেশ ও Radiant-looking</strong> রাখতে সহায়তা করে। ✨</p>
      </div>
    </div>
    <?php endif; ?>
  </div>
</section>
<?php endif; ?>

<!-- ===== CUSTOMER REVIEWS VIDEOS ===== -->
<?php 
$r_vid1 = $rev_video1 ?: ($is_beauty_milk ? 'lOK9KbIB75g' : '');
$r_vid2 = $rev_video2 ?: ($is_beauty_milk ? 'AWEf1LyTt5Q' : '');
if ($r_vid1 || $r_vid2) : ?>
<section class="spd-reviews-section" id="spd-reviews">
  <div class="container">
    <h2 class="section-title">Customer Reviews</h2>
    <div class="section-divider"></div>
    <div class="spd-video-reviews">
      <?php if ($r_vid1) : ?>
        <div class="video-review-card">
          <div class="video-wrapper">
            <iframe src="https://www.youtube.com/embed/<?php echo esc_attr($r_vid1); ?>?enablejsapi=1&rel=0&modestbranding=1"
              title="Customer Review 1 — <?php echo esc_attr($product_name); ?>"
              frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowfullscreen loading="lazy"></iframe>
          </div>
          <div class="video-review-info">
            <div class="vr-stars">★★★★★</div>
            <p class="vr-label">Customer Review</p>
            <span class="vr-verified">✓ Verified Purchase</span>
          </div>
        </div>
      <?php endif; ?>
      <?php if ($r_vid2) : ?>
        <div class="video-review-card">
          <div class="video-wrapper">
            <iframe src="https://www.youtube.com/embed/<?php echo esc_attr($r_vid2); ?>?enablejsapi=1&rel=0&modestbranding=1"
              title="Customer Review 2 — <?php echo esc_attr($product_name); ?>"
              frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowfullscreen loading="lazy"></iframe>
          </div>
          <div class="video-review-info">
            <div class="vr-stars">★★★★★</div>
            <p class="vr-label">Customer Review</p>
            <span class="vr-verified">✓ Verified Purchase</span>
          </div>
        </div>
      <?php endif; ?>
    </div>
  </div>
</section>
<?php endif; ?>

<!-- ===== RESULT TIMELINE (only if result_days set) ===== -->
<?php if ($result_days) : ?>
<section class="spd-timeline-section" id="spd-timeline">
  <div class="container">
    <span class="gold-badge">Result Timeline</span>
    <h2 class="section-title">কখন Result পাবেন?</h2>
    <div class="section-divider"></div>
    <div class="spd-timeline">
      <div class="tl-step tl-step-1">
        <div class="tl-bubble tl-bubble-1">৭ দিন</div>
        <div class="tl-content">
          <h4>প্রথম পরিবর্তন</h4>
          <p>ত্বক Hydrated ও Fresh অনুভব হবে।</p>
        </div>
      </div>
      <div class="tl-connector"></div>
      <div class="tl-step tl-step-2">
        <div class="tl-bubble tl-bubble-2 active"><?php echo esc_html($result_days); ?> দিন</div>
        <div class="tl-content">
          <h4>Visible Change ✨</h4>
          <p>দৃশ্যমান পরিবর্তন লক্ষ্য করবেন।</p>
        </div>
      </div>
      <div class="tl-connector"></div>
      <div class="tl-step tl-step-3">
        <div class="tl-bubble tl-bubble-3"><?php echo esc_html($result_days * 2); ?> দিন</div>
        <div class="tl-content">
          <h4>Full Transformation 💫</h4>
          <p>সর্বোচ্চ ফলাফল পাবেন।</p>
        </div>
      </div>
    </div>
  </div>
</section>
<?php endif; ?>

<!-- ===== HOW TO USE (from description or meta) ===== -->
<?php
$content      = get_the_content();
$htu_html     = '';
$htu_steps    = [];

// 1. Try parsing from description
if (preg_match('/<h3[^>]*>How to Use<\/h3>(.*?)(?=<h3|$)/si', $content, $m)) {
    $htu_html = trim($m[1]);
    preg_match_all('/<(?:li|p)[^>]*>(.*?)<\/(?:li|p)>/si', $htu_html, $it);
    foreach ($it[1] as $item) {
        $t = trim(strip_tags($item));
        if (strlen($t) > 5) $htu_steps[] = $t;
    }
}
// 2. Fallback: sob_how_to_use meta
if (empty($htu_steps) && $how_to_use) {
    $parts = array_filter(array_map('trim', explode('.', $how_to_use)));
    foreach ($parts as $p) {
        if (strlen($p) > 3) $htu_steps[] = $p . '.';
    }
}

$bn_nums = ['১','২','৩','৪','৫','৬','৭','৮','৯','১০'];
if (!empty($htu_steps)) :
?>
<section class="spd-usage-section" id="spd-usage">
  <div class="container">
    <span class="gold-badge">ব্যবহার বিধি</span>
    <h2 class="section-title">কীভাবে ব্যবহার করবেন?</h2>
    <div class="section-divider"></div>
    <div class="spd-usage-steps">
      <?php foreach ($htu_steps as $i => $step) : ?>
        <div class="usage-step">
          <div class="us-num"><?php echo isset($bn_nums[$i]) ? $bn_nums[$i] : ($i+1); ?></div>
          <div class="us-body">
            <p><?php echo esc_html($step); ?></p>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>
<?php endif; ?>

<!-- ===== PRODUCT DETAIL SECTIONS (auto-parsed from description h3 headings) ===== -->
<?php
// Parse ALL h3 sections from product description
$full_desc = get_the_content();
$parsed_sections = [];
preg_match_all('/<h3[^>]*>(.*?)<\/h3>(.*?)(?=<h3|$)/si', $full_desc, $sec_matches, PREG_SET_ORDER);
foreach ($sec_matches as $sm) {
    $sec_title = trim(strip_tags($sm[1]));
    $sec_body  = trim($sm[2]);
    if ($sec_title && $sec_body) $parsed_sections[$sec_title] = $sec_body;
}

function sob_get_section($sections, $keywords) {
    foreach ($keywords as $kw) {
        foreach ($sections as $title => $body) {
            if (stripos($title, $kw) !== false) return $body;
        }
    }
    return '';
}
function sob_parse_benefits($html) {
    $items = [];
    preg_match_all('/<li[^>]*>(.*?)<\/li>/si', $html, $m);
    foreach ($m[1] as $li) { $t = trim(strip_tags($li)); if (strlen($t) > 3) $items[] = $t; }
    if (empty($items)) {
        preg_match_all('/<p[^>]*>(.*?)<\/p>/si', $html, $m2);
        foreach ($m2[1] as $p) { $t = trim(strip_tags($p)); if (strlen($t) > 5) $items[] = $t; }
    }
    return $items;
}

$sec_benefits   = sob_get_section($parsed_sections, ['Key Benefits','Benefits','উপকারিতা','সুবিধাসমূহ']);
$sec_note       = sob_get_section($parsed_sections, ['Important Note','Important Information','Important Precaution','Precaution','জরুরী নির্দেশনা','সতর্কতা']);
$sec_storage    = sob_get_section($parsed_sections, ['Storage','সংরক্ষণ']);
$sec_auth       = sob_get_section($parsed_sections, ['Authenticity','Authentic','পণ্যের আসল নিশ্চয়তা']);
$sec_disclaimer = sob_get_section($parsed_sections, ['Disclaimer','ডিসক্লেইমার']);
$sec_suitable   = sob_get_section($parsed_sections, ['Suitable For','Skin Type','কাদের জন্য উপযোগী']);

$meta_benefits   = get_post_meta($pid, 'sob_key_benefits', true);
$meta_note       = get_post_meta($pid, 'sob_important_note', true);
$meta_storage    = get_post_meta($pid, 'sob_storage', true);
$meta_auth       = get_post_meta($pid, 'sob_authenticity', true);
$meta_disclaimer = get_post_meta($pid, 'sob_disclaimer', true);

// ── KEY BENEFITS ──
$benefit_items = sob_parse_benefits($sec_benefits ?: '');
if (empty($benefit_items) && $meta_benefits) {
    $benefit_items = array_filter(array_map('trim', explode("\n", $meta_benefits)));
}
?>

<?php if (!empty($benefit_items)) : ?>
<section class="spd-benefits-section" id="spd-benefits">
  <div class="container">
    <span class="gold-badge">উপকারিতা</span>
    <h2 class="section-title">কেন এই Product বেছে নেবেন?</h2>
    <div class="section-divider"></div>
    <div class="spd-benefits-grid">
      <?php foreach ($benefit_items as $benefit) :
        $benefit = trim(ltrim(trim($benefit), '●•✨⭐✓✔-*'));
        if (strlen($benefit) < 3) continue; ?>
        <div class="benefit-card">
          <div class="benefit-check">✓</div>
          <p><?php echo esc_html($benefit); ?></p>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>
<?php endif; ?>

<?php if ($sec_note || $meta_note || $sec_storage || $meta_storage || $sec_auth || $meta_auth || $sec_suitable) : ?>
<section class="spd-info-cards-section" id="spd-info-cards">
  <div class="container">
    <div class="spd-info-grid">

      <?php if ($sec_note || $meta_note) : ?>
      <div class="info-card info-card--warning">
        <div class="ic-header"><span class="ic-icon">⚠️</span><h3>জরুরী নির্দেশনা</h3></div>
        <p><?php echo esc_html($meta_note ?: strip_tags($sec_note)); ?></p>
      </div>
      <?php endif; ?>

      <?php if ($sec_storage || $meta_storage) : ?>
      <div class="info-card info-card--storage">
        <div class="ic-header"><span class="ic-icon">📦</span><h3>সংরক্ষণ পদ্ধতি</h3></div>
        <p><?php echo esc_html($meta_storage ?: strip_tags($sec_storage)); ?></p>
      </div>
      <?php endif; ?>

      <?php if ($sec_auth || $meta_auth) : ?>
      <div class="info-card info-card--auth">
        <div class="ic-header"><span class="ic-icon">🔐</span><h3>পণ্যের আসল নিশ্চয়তা</h3></div>
        <p><?php echo esc_html($meta_auth ?: strip_tags($sec_auth)); ?></p>
      </div>
      <?php endif; ?>

      <?php if ($sec_suitable) : ?>
      <div class="info-card info-card--skin">
        <div class="ic-header"><span class="ic-icon">🧴</span><h3>কাদের জন্য উপযোগী</h3></div>
        <p><?php echo esc_html(strip_tags($sec_suitable)); ?></p>
      </div>
      <?php endif; ?>

    </div>
  </div>
</section>
<?php endif; ?>

<!-- ===== IMPORTANT DISCLAIMER / NOTE ===== -->
<section class="spd-disclaimer-section" id="spd-disclaimer">
  <div class="container">
    <div class="spd-disclaimer-inner">
      <span class="disclaimer-icon">📋</span>
      <div class="disclaimer-text-wrap">
        <h4>জরুরি সতর্কতা ও ডিসক্লেইমার</h4>
        <p><?php 
          $custom_disclaimer = $meta_disclaimer ?: strip_tags($sec_disclaimer);
          if (!empty($custom_disclaimer)) {
              echo esc_html($custom_disclaimer);
          } else {
              echo 'ব্যক্তিভেদে ব্যবহারের ফলাফল ভিন্ন হতে পারে। সঠিক ব্যবহারের জন্য সর্বদা প্রস্তুতকারকের আসল প্যাকেজিং ও দিকনির্দেশনা মেনে চলুন। এই পণ্যগুলো কোনো রোগ নির্ণয়, চিকিৎসা বা নিরাময়ের জন্য নয়।';
          }
        ?></p>
      </div>
    </div>
  </div>
</section>



<!-- ===== REFUND POLICY (show if guarantee or result_days set) ===== -->
<?php if ($guarantee || $result_days) : ?>
<section class="spd-refund-section" id="spd-refund">
  <div class="container">
    <div class="spd-refund-inner">
      <div class="refund-icon">🛡️</div>
      <div class="refund-text">
        <h2>ফলাফল ও রিফান্ড নীতি</h2>
        <p>প্রত্যেক ব্যক্তির skin type ও lifestyle অনুযায়ী ফলাফল পাওয়ার সময় ভিন্ন হতে পারে।
          <?php if ($result_days) : ?>
          নিয়মিত ব্যবহারে সাধারণত <strong><?php echo esc_html($result_days); ?> দিনের মধ্যে</strong> দৃশ্যমান পরিবর্তন আসে।
          <?php endif; ?>
        </p>
        <p style="margin-top:12px;">প্রত্যাশিত পরিবর্তন না আসলে — <strong><?php echo $guarantee ? esc_html($guarantee) : '১০০% মানি-ব্যাক গ্যারান্টি।'; ?></strong></p>
      </div>
    </div>
  </div>
</section>
<?php endif; ?>


<!-- ===== DIRECT CHECKOUT SECTION ===== -->
<section class="spd-checkout-section" id="spd-checkout">
  <div class="container spd-checkout-container">
    <h2 class="section-title spd-checkout-title">অর্ডার করতে নিচের ফর্মটি পূরণ করুন 👇</h2>
    <div class="woocommerce" style="color: var(--sob-dark, #1c1c26);">
      <?php
      if ( function_exists('WC') && WC()->cart && ! wp_doing_ajax() ) {
          $cart_items = WC()->cart->get_cart();
          $has_this_product = false;
          foreach ( $cart_items as $item ) {
              if ( isset($item['product_id']) && $item['product_id'] == $pid ) {
                  $has_this_product = true;
                  break;
              }
          }
          if ( ! $has_this_product || empty($cart_items) ) {
              WC()->cart->empty_cart();
              WC()->cart->add_to_cart( $pid, 1 );
          }
      }
      echo do_shortcode('[woocommerce_checkout]');
      ?>
    </div>
  </div>
</section>

</main>

<style>
/* ========================================
   SINGLE PRODUCT PAGE — DARK PREMIUM
   ======================================== */
.spd-hero { padding: 60px 0 80px; }
.spd-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 60px; align-items: start; }
.spd-img-wrapper { position: relative; border-radius: 20px; overflow: hidden; border: 1px solid rgba(201,169,110,0.2); box-shadow: 0 20px 60px rgba(0,0,0,0.5); background: var(--dark-surface); }

/* Video Reordering for Mobile */
.spd-video-mobile-only { display: none; }
.spd-video-desktop-only { display: block; }
/* ===== PREMIUM GALLERY ===== */
.spd-gallery { position: relative; width: 100%; }
.spd-gallery-main { position: relative; width: 100%; background: var(--dark-card); border-radius: var(--radius-lg); overflow: hidden; border: 1px solid rgba(201,169,110,0.2); box-shadow: 0 20px 60px rgba(0,0,0,0.5); }
.spd-main-img { width: 100%; height: 420px; object-fit: contain; display: block; transition: opacity 0.25s ease; background: var(--dark-card); cursor: zoom-in; }
.gallery-arrow { position: absolute; top: 50%; transform: translateY(-50%); z-index: 10; width: 40px; height: 40px; background: rgba(10,10,10,0.75); border: 1px solid rgba(201,169,110,0.35); color: var(--gold); font-size: 1.8rem; border-radius: 50%; cursor: pointer; display: flex; align-items: center; justify-content: center; transition: background 0.2s, border-color 0.2s; line-height: 1; padding: 0; }
.gallery-arrow:hover { background: rgba(201,169,110,0.15); border-color: var(--gold); }
.gallery-arrow--prev { left: 10px; }
.gallery-arrow--next { right: 10px; }
.gallery-counter { position: absolute; bottom: 10px; right: 12px; background: rgba(0,0,0,0.65); color: #fff; font-size: 0.78rem; padding: 3px 10px; border-radius: 20px; backdrop-filter: blur(4px); pointer-events: none; }
.gallery-zoom-hint { position: absolute; bottom: 10px; left: 12px; background: rgba(0,0,0,0.5); color: rgba(255,255,255,0.65); font-size: 0.72rem; padding: 3px 10px; border-radius: 20px; pointer-events: none; transition: opacity 0.3s; }
.spd-gallery-main:hover .gallery-zoom-hint { opacity: 0; }
/* Thumbnails */
.spd-thumbs-row { display: flex; gap: 8px; margin-top: 10px; overflow-x: auto; padding-bottom: 4px; -webkit-overflow-scrolling: touch; flex-wrap: nowrap; }
.spd-thumbs-row::-webkit-scrollbar { height: 4px; }
.spd-thumbs-row::-webkit-scrollbar-thumb { background: var(--dark-border); border-radius: 2px; }
.spd-thumb { flex-shrink: 0; width: 72px; height: 72px; border-radius: 8px; overflow: hidden; border: 2px solid var(--dark-border); cursor: pointer; transition: border-color 0.2s, transform 0.2s; background: var(--dark-card); }
.spd-thumb img { width: 100%; height: 100%; object-fit: cover; display: block; }
.spd-thumb:hover { border-color: rgba(201,169,110,0.5); transform: translateY(-2px); }
.spd-thumb.active { border-color: var(--gold); box-shadow: 0 0 0 2px rgba(201,169,110,0.2); }
/* Lightbox */
.spd-lightbox { display: none; position: fixed; inset: 0; z-index: 99999; background: rgba(0,0,0,0.93); align-items: center; justify-content: center; backdrop-filter: blur(8px); -webkit-backdrop-filter: blur(8px); animation: lb-fadein 0.2s ease; }
@keyframes lb-fadein { from { opacity: 0; } to { opacity: 1; } }
.spd-lightbox.open { display: flex; }
.lb-img-wrap { max-width: 90vw; max-height: 88vh; display: flex; align-items: center; justify-content: center; }
.lb-img { max-width: 90vw; max-height: 85vh; object-fit: contain; border-radius: 8px; box-shadow: 0 20px 80px rgba(0,0,0,0.8); }
.lb-close { position: fixed; top: 18px; right: 20px; width: 44px; height: 44px; background: rgba(255,255,255,0.1); border: 1px solid rgba(255,255,255,0.2); color: #fff; font-size: 1.1rem; border-radius: 50%; cursor: pointer; z-index: 100000; display: flex; align-items: center; justify-content: center; transition: background 0.2s; }
.lb-close:hover { background: rgba(255,100,100,0.3); }
.lb-arrow { position: fixed; top: 50%; transform: translateY(-50%); width: 52px; height: 52px; background: rgba(255,255,255,0.08); border: 1px solid rgba(255,255,255,0.15); color: #fff; font-size: 2.2rem; border-radius: 50%; cursor: pointer; z-index: 100000; display: flex; align-items: center; justify-content: center; transition: background 0.2s; line-height: 1; padding: 0; }
.lb-arrow:hover { background: rgba(255,255,255,0.15); }
.lb-arrow--prev { left: 16px; }
.lb-arrow--next { right: 16px; }
.lb-counter { position: fixed; bottom: 24px; left: 50%; transform: translateX(-50%); background: rgba(255,255,255,0.1); color: rgba(255,255,255,0.8); font-size: 0.85rem; padding: 5px 16px; border-radius: 20px; z-index: 100000; }
.spd-no-img { aspect-ratio: 1/1; display: flex; align-items: center; justify-content: center; background: linear-gradient(135deg, #111, #0d0d0d); }
.spd-no-img-inner { text-align: center; }
.spd-no-img-inner span { font-size: 6rem; display: block; margin-bottom: 12px; }
.spd-no-img-inner p { color: var(--gold); font-size: 1.1rem; font-weight: 600; }
.spd-badge-sale { position: absolute; top: 16px; left: 16px; background: #e74c3c; color: #fff; font-size: 0.8rem; font-weight: 700; padding: 4px 12px; border-radius: 50px; z-index: 3; }
.spd-badge-top { position: absolute; top: 16px; right: 16px; background: linear-gradient(135deg, var(--gold), var(--gold-dark)); color: var(--dark-bg); font-size: 0.75rem; font-weight: 700; padding: 4px 12px; border-radius: 50px; z-index: 3; }
.spd-guarantee-badge { position: absolute; bottom: 0; left: 0; right: 0; background: rgba(10,10,10,0.92); backdrop-filter: blur(12px); border-top: 1px solid rgba(201,169,110,0.2); padding: 14px 20px; display: flex; align-items: center; gap: 16px; font-size: 0.82rem; }
.gb-icon { font-size: 1.6rem; flex-shrink: 0; }
.spd-guarantee-badge strong { display: block; color: var(--gold); font-size: 0.9rem; }
.spd-guarantee-badge span { color: var(--text-muted); font-size: 0.78rem; }
.gb-divider { width: 1px; height: 32px; background: rgba(201,169,110,0.2); flex-shrink: 0; }
.spd-thumbs-row { display: flex; gap: 10px; margin-top: 12px; flex-wrap: wrap; }
.spd-thumb { width: 72px; height: 72px; border-radius: 8px; overflow: hidden; border: 2px solid var(--dark-border); cursor: pointer; transition: border-color 0.2s; }
.spd-thumb img { width: 100%; height: 100%; object-fit: cover; }
.spd-thumb.active, .spd-thumb:hover { border-color: var(--gold); }
.spd-trust-row { display: flex; gap: 8px; flex-wrap: wrap; margin-top: 16px; }
.trust-badge { flex: 1; min-width: 80px; padding: 8px 10px; background: var(--dark-card); border: 1px solid var(--dark-border); border-radius: var(--radius); font-size: 0.78rem; color: var(--text-secondary); text-align: center; display: flex; align-items: center; justify-content: center; gap: 4px; }
.spd-breadcrumb { font-size: 0.82rem; color: var(--text-muted); margin-bottom: 16px; display: flex; align-items: center; gap: 6px; flex-wrap: wrap; }
.spd-breadcrumb a { color: var(--text-muted); }
.spd-breadcrumb a:hover { color: var(--gold); }
.spd-title {
  font-family: var(--font-heading);
  font-size: clamp(1.25rem, 2.8vw, 2.2rem);
  color: var(--text-primary);
  margin-bottom: 14px;
  line-height: 1.25;
}
.spd-rating { display: flex; align-items: center; gap: 10px; margin-bottom: 16px; flex-wrap: wrap; }
.stars-lg { color: var(--gold); font-size: 1.1rem; }
.rating-num { font-weight: 700; color: var(--gold); }
.rating-count { color: var(--text-muted); font-size: 0.88rem; }
.spd-sold { color: var(--text-muted); font-size: 0.88rem; }
/* Landing Page Custom Headline & Subheadline */
.spd-landing-headline {
  font-family: var(--font-heading) !important;
  font-size: clamp(0.78rem, 2.1vw, 1.45rem) !important;
  font-weight: 800 !important;
  color: var(--sob-dark, #1c1c26) !important;
  line-height: 1.3 !important;
  margin: 0 auto 12px auto !important;
  white-space: nowrap !important;
  display: block !important;
  width: 100% !important;
  text-align: center !important;
  letter-spacing: -0.2px;
}

.spd-gold-gradient {
  background: linear-gradient(135deg, var(--sob-primary, #a11ff1), var(--sob-pink, #ff4fa3)) !important;
  -webkit-background-clip: text !important;
  -webkit-text-fill-color: transparent !important;
  background-clip: text !important;
  display: inline !important;
  font-weight: 800 !important;
}

.spd-landing-subheadline {
  display: flex !important;
  flex-direction: column !important;
  align-items: center !important;
  justify-content: center !important;
  text-align: center !important;
  gap: 6px !important;
  margin: 0 auto 12px auto !important;
  width: 100% !important;
  background: var(--sob-light, #f7f5fb);
  border: 1px solid var(--sob-border, #ececf3);
  border-radius: 12px;
  padding: 10px 14px;
  box-sizing: border-box;
}

.spd-landing-subheadline .sub-line {
  display: block !important;
  white-space: nowrap !important;
  text-align: center !important;
  font-family: var(--font-body) !important;
  font-size: clamp(0.64rem, 1.35vw, 0.92rem) !important;
  line-height: 1.45 !important;
}

.spd-landing-subheadline .sub-line-1 {
  color: var(--sob-dark, #1c1c26) !important;
  font-weight: 600;
}

.spd-landing-subheadline .sub-line-2 {
  color: var(--sob-primary, #a11ff1) !important;
  font-weight: 700 !important;
}

@media (max-width: 1024px) {
  .spd-landing-headline {
    font-size: clamp(0.85rem, 3.8vw, 1.6rem) !important;
  }
  .spd-landing-subheadline .sub-line {
    font-size: clamp(0.68rem, 2.5vw, 0.95rem) !important;
  }
}

@media (max-width: 480px) {
  .spd-landing-headline {
    font-size: clamp(0.72rem, 3.5vw, 1.05rem) !important;
    margin-bottom: 8px !important;
  }
  .spd-landing-subheadline {
    padding: 8px 10px !important;
    gap: 4px !important;
    margin-bottom: 16px !important;
  }
  .spd-landing-subheadline .sub-line {
    font-size: clamp(0.58rem, 2.55vw, 0.82rem) !important;
  }
}

.spd-tagline {
  background: var(--sob-light, #f7f5fb);
  border: 1px solid var(--sob-border, #ececf3);
  border-left: 3px solid var(--sob-primary, #a11ff1);
  border-radius: 0 var(--radius) var(--radius) 0;
  padding: 10px 14px;
  font-size: clamp(0.84rem, 2vw, 0.95rem);
  color: var(--sob-gray, #6b6b76);
  margin-bottom: 18px;
  line-height: 1.45;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}
.spd-tagline strong { color: var(--sob-primary, #a11ff1); }
.spd-price-box { display: flex; align-items: center; gap: 12px; margin-bottom: 16px; flex-wrap: wrap; }
.spd-old-price { font-size: 1.1rem; color: var(--sob-muted, #9494a2); }
.spd-current-price { font-size: 2rem; font-weight: 800; color: var(--sob-primary, #a11ff1); font-family: var(--font-heading); }
.spd-save-badge { padding: 4px 12px; background: var(--sob-pink-light, #ffeef6); border: 1px solid rgba(255, 79, 163, 0.3); color: var(--sob-pink, #ff4fa3); border-radius: 50px; font-size: 0.82rem; font-weight: 700; }
.spd-short-desc { color: var(--sob-gray, #6b6b76); font-size: 0.95rem; line-height: 1.7; margin-bottom: 16px; }
.spd-ingr-row { display: flex; gap: 8px; flex-wrap: wrap; margin-bottom: 16px; }
.ingr-chip { padding: 6px 14px; background: var(--sob-light, #f7f5fb); border: 1px solid var(--sob-border, #ececf3); border-radius: 50px; font-size: 0.82rem; color: var(--sob-primary, #a11ff1); font-weight: 600; display: flex; align-items: center; gap: 4px; }
.spd-stock-row { display: flex; align-items: center; gap: 16px; margin-bottom: 20px; }
.stock-in { color: #10b981; font-size: 0.9rem; font-weight: 600; }
.stock-low { color: #e8a730; font-size: 0.85rem; }
.stock-out { color: #e74c3c; font-size: 0.9rem; font-weight: 600; }
.spd-order-box { margin-bottom: 20px; display: flex; flex-direction: column; gap: 10px; }
.spd-qty-row { display: flex; align-items: center; gap: 16px; margin-bottom: 6px; font-size: 0.9rem; color: var(--sob-gray, #6b6b76); }
.qty-control { display: flex; align-items: center; border: 1px solid var(--sob-border, #ececf3); border-radius: var(--radius); overflow: hidden; }
.qty-btn { width: 36px; height: 36px; background: var(--sob-light, #f7f5fb); border: none; color: var(--sob-dark, #1c1c26); font-size: 1.1rem; cursor: pointer; display: flex; align-items: center; justify-content: center; transition: background 0.2s; }
.qty-btn:hover { background: var(--sob-primary-light, #f3e5fd); color: var(--sob-primary, #a11ff1); }
.qty-num { width: 44px; text-align: center; font-weight: 600; color: var(--sob-dark, #1c1c26); font-size: 1rem; }
.spd-order-btn { display: flex; align-items: center; justify-content: center; gap: 8px; width: 100%; padding: 16px; background: linear-gradient(135deg, var(--sob-primary, #a11ff1), var(--sob-primary-dark, #7c17c2)); color: #ffffff !important; font-weight: 700; font-size: 1.05rem; border: none; border-radius: var(--radius); cursor: pointer; transition: opacity 0.2s, box-shadow 0.3s; text-decoration: none; text-align: center; font-family: var(--font-body); box-sizing: border-box; }
.spd-order-btn:hover { opacity: 0.95; box-shadow: 0 8px 30px rgba(161, 31, 241, 0.4); color: #ffffff !important; }
.spd-buynow-btn { display: flex; align-items: center; justify-content: center; gap: 8px; width: 100%; padding: 14px; background: transparent; color: var(--sob-primary, #a11ff1); font-weight: 700; font-size: 0.95rem; border: 2px solid var(--sob-primary, #a11ff1); border-radius: var(--radius); cursor: pointer; transition: all 0.3s; text-decoration: none; text-align: center; font-family: var(--font-body); box-sizing: border-box; }
.spd-buynow-btn:hover { background: var(--sob-primary-light, #f3e5fd); color: var(--sob-primary, #a11ff1); }
.spd-delivery { padding: 16px; background: var(--sob-light, #f7f5fb); border: 1px solid var(--sob-border, #ececf3); border-radius: var(--radius); display: flex; flex-direction: column; gap: 8px; }
.dlv-item { display: flex; align-items: center; gap: 8px; font-size: 0.85rem; color: var(--sob-gray, #6b6b76); }
.dlv-item span { font-size: 1rem; flex-shrink: 0; }

/* Video section */
.spd-video-section { padding: 60px 0; background: var(--sob-light, #f7f5fb); text-align: center; }
.spd-video-subtitle { color: var(--sob-muted, #9494a2); font-size: 0.95rem; margin: -4px 0 8px; }
.spd-product-video-wrap { display: grid; grid-template-columns: 1fr 320px; gap: 40px; margin-top: 36px; align-items: center; text-align: left; }
.spd-product-video-inner { position: relative; padding: 12px; }
.pv-corner { position: absolute; width: 24px; height: 24px; border-color: var(--sob-primary, #a11ff1); border-style: solid; z-index: 2; }
.pv-tl { top: 0; left: 0; border-width: 2px 0 0 2px; border-radius: 4px 0 0 0; }
.pv-tr { top: 0; right: 0; border-width: 2px 2px 0 0; border-radius: 0 4px 0 0; }
.pv-bl { bottom: 0; left: 0; border-width: 0 0 2px 2px; border-radius: 0 0 0 4px; }
.pv-br { bottom: 0; right: 0; border-width: 0 2px 2px 0; border-radius: 0 0 4px 0; }
.spd-product-iframe-box { position: relative; width: 100%; aspect-ratio: 16/9; background: #000; border-radius: 12px; overflow: hidden; border: 1px solid var(--sob-border, #ececf3); box-shadow: 0 16px 40px rgba(0,0,0,0.12); }
.spd-product-iframe-box iframe { position: absolute; top: 0; left: 0; width: 100%; height: 100%; border: none; }
.spd-video-side { display: flex; flex-direction: column; gap: 16px; }
.vside-item { display: flex; align-items: flex-start; gap: 14px; padding: 16px; background: #ffffff; border: 1px solid var(--sob-border, #ececf3); border-radius: var(--radius); transition: border-color 0.3s, transform 0.3s; box-shadow: 0 4px 15px rgba(0,0,0,0.04); }
.vside-item:hover { border-color: var(--sob-primary, #a11ff1); transform: translateX(4px); }
.vside-icon { font-size: 1.4rem; flex-shrink: 0; width: 40px; height: 40px; background: var(--sob-primary-light, #f3e5fd); border-radius: 8px; display: flex; align-items: center; justify-content: center; }
.vside-item h4 { font-size: 0.92rem; color: var(--sob-dark, #1c1c26); margin-bottom: 3px; font-weight: 700; }
.vside-item p { font-size: 0.82rem; color: var(--sob-gray, #6b6b76); line-height: 1.4; }
.vside-btn { display: flex; align-items: center; justify-content: center; gap: 8px; padding: 14px 20px; background: linear-gradient(135deg, var(--sob-primary, #a11ff1), var(--sob-primary-dark, #7c17c2)); color: #ffffff !important; font-weight: 700; font-size: 0.95rem; border-radius: var(--radius); text-decoration: none; transition: opacity 0.2s, box-shadow 0.3s, transform 0.2s; font-family: var(--font-body); margin-top: 8px; }
.vside-btn:hover { opacity: 0.95; transform: translateY(-2px); box-shadow: 0 8px 24px rgba(161, 31, 241, 0.35); color: #ffffff !important; }

/* How section */
.spd-how-section { padding: 60px 0; background: var(--sob-light, #f7f5fb); text-align: center; }
.spd-how-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 24px; margin: 40px 0 28px; }
.how-card { background: #ffffff; border: 1px solid var(--sob-border, #ececf3); border-radius: var(--radius-lg); padding: 32px 22px; transition: var(--transition); box-shadow: 0 4px 15px rgba(0,0,0,0.04); }
.how-card:hover { border-color: var(--sob-primary, #a11ff1); transform: translateY(-6px); box-shadow: 0 12px 30px rgba(161, 31, 241, 0.12); }
.how-icon { font-size: 2.5rem; margin-bottom: 16px; }
.how-card h3 { font-family: var(--font-heading); font-size: 1.15rem; color: var(--sob-dark, #1c1c26); margin-bottom: 12px; font-weight: 700; }
.how-card p { color: var(--sob-gray, #6b6b76); font-size: 0.92rem; line-height: 1.7; }
.how-card strong { color: var(--sob-dark, #1c1c26); }
.spd-combined { display: flex; align-items: center; gap: 24px; background: var(--sob-primary-light, #f3e5fd); border: 1px solid rgba(161, 31, 241, 0.2); border-radius: var(--radius-lg); padding: 24px 28px; text-align: left; }
.combined-icon { font-size: 2.5rem; flex-shrink: 0; }
.spd-combined h3 { color: var(--sob-primary, #a11ff1); font-family: var(--font-heading); margin-bottom: 8px; }
.spd-combined p { color: var(--sob-gray, #6b6b76); line-height: 1.7; }
.spd-combined strong { color: var(--sob-dark, #1c1c26); }

/* Timeline */
.spd-timeline-section { padding: 60px 0; text-align: center; background: #ffffff; }
.spd-timeline { display: flex; align-items: center; justify-content: center; gap: 0; margin-top: 48px; flex-wrap: wrap; }
.tl-step { display: flex; flex-direction: column; align-items: center; max-width: 240px; }
.tl-bubble { border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: 800; margin-bottom: 16px; transition: all 0.3s ease; }

/* 1st Circle: Smallest (একটু ছোট) */
.tl-bubble-1 {
  width: 68px;
  height: 68px;
  background: var(--sob-light, #f7f5fb);
  border: 1.5px solid var(--sob-border, #ececf3);
  color: var(--sob-gray, #6b6b76);
  font-size: 0.88rem;
}

/* 2nd Circle: Middle / Medium (মাঝের টা আর একটু বড়) */
.tl-bubble-2 {
  width: 94px;
  height: 94px;
  background: linear-gradient(135deg, var(--sob-pink, #ff4fa3) 0%, #e03287 100%);
  border: 2px solid #ffffff;
  color: #ffffff;
  font-size: 1.1rem;
  font-weight: 800;
  box-shadow: 0 8px 24px rgba(255, 79, 163, 0.35);
}

/* 3rd Circle: Largest (লাস্টের টা আর একটু বড়) */
.tl-bubble-3 {
  width: 122px;
  height: 122px;
  background: linear-gradient(135deg, var(--sob-primary, #a11ff1) 0%, var(--sob-primary-dark, #7c17c2) 100%);
  border: 2.5px solid #ffffff;
  color: #ffffff;
  font-size: 1.3rem;
  font-weight: 800;
  box-shadow: 0 10px 32px rgba(161, 31, 241, 0.4);
}

.tl-connector { width: 60px; height: 3px; background: linear-gradient(90deg, var(--sob-pink, #ff4fa3), var(--sob-primary, #a11ff1)); margin-top: -30px; flex-shrink: 0; }
.tl-content { text-align: center; padding: 0 12px; }
.tl-content h4 { color: var(--sob-dark, #1c1c26); font-size: 0.95rem; margin-bottom: 6px; font-weight: 700; }
.tl-content p { color: var(--sob-gray, #6b6b76); font-size: 0.82rem; line-height: 1.5; }

/* Usage */
.spd-usage-section { padding: 60px 0; background: var(--sob-light, #f7f5fb); text-align: center; }
.spd-usage-steps { display: grid; grid-template-columns: repeat(4, 1fr); gap: 20px; margin-top: 40px; }
.usage-step { background: #ffffff; border: 1px solid var(--sob-border, #ececf3); border-radius: var(--radius-lg); padding: 26px 18px; text-align: left; box-shadow: 0 4px 15px rgba(0,0,0,0.04); }
.us-num { width: 40px; height: 40px; background: linear-gradient(135deg, var(--sob-primary, #a11ff1), var(--sob-primary-dark, #7c17c2)); color: #ffffff; font-weight: 700; font-size: 1.1rem; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin-bottom: 16px; }
.us-body h4 { color: var(--sob-dark, #1c1c26); font-size: 0.95rem; margin-bottom: 6px; font-weight: 700; }
.us-body p { color: var(--sob-gray, #6b6b76); font-size: 0.85rem; line-height: 1.5; }

/* Reviews */
.spd-reviews-section { padding: 60px 0; text-align: center; background: #ffffff; }
.spd-video-reviews { display: grid; grid-template-columns: repeat(2, 1fr); gap: 32px; margin: 40px auto 36px; max-width: 760px; }
.video-review-card { background: #ffffff; border: 1px solid var(--sob-border, #ececf3); border-radius: var(--radius-lg); overflow: hidden; transition: var(--transition); box-shadow: 0 4px 15px rgba(0,0,0,0.04); }
.video-review-card:hover { border-color: var(--sob-primary, #a11ff1); box-shadow: 0 12px 30px rgba(161, 31, 241, 0.12); transform: translateY(-4px); }
.video-wrapper { position: relative; width: 100%; aspect-ratio: 9/16; background: #000; overflow: hidden; }
.video-wrapper iframe { position: absolute; top: 0; left: 0; width: 100%; height: 100%; border: none; }
.video-review-info { padding: 16px; text-align: center; background: #ffffff; border-top: 1px solid var(--sob-border-light, #f0f0f7); }
.vr-stars { color: #f59e0b; font-size: 1rem; letter-spacing: 2px; margin-bottom: 6px; }
.vr-label { color: var(--sob-gray, #6b6b76); font-size: 0.88rem; margin-bottom: 4px; }
.vr-verified { color: #10b981; font-size: 0.78rem; font-weight: 600; }

/* Refund */
.spd-refund-section { padding: 60px 0; background: var(--sob-light, #f7f5fb); }
.spd-refund-inner { display: flex; align-items: center; gap: 32px; background: #ffffff; border: 1px solid var(--sob-border, #ececf3); border-radius: var(--radius-lg); padding: 36px 40px; box-shadow: 0 4px 15px rgba(0,0,0,0.04); }
.refund-icon { font-size: 3.5rem; flex-shrink: 0; }
.refund-text h2 { font-family: var(--font-heading); font-size: 1.5rem; color: var(--sob-dark, #1c1c26); margin-bottom: 12px; font-weight: 700; }
.refund-text p { color: var(--sob-gray, #6b6b76); line-height: 1.7; font-size: 0.95rem; }
.refund-text strong { color: var(--sob-primary, #a11ff1); }

/* Final CTA */
.spd-final-order { padding: 60px 0; background: #ffffff; }
.spd-final-inner { position: relative; text-align: center; background: var(--sob-light, #f7f5fb); border: 1px solid var(--sob-border, #ececf3); border-radius: 24px; padding: 50px 36px; overflow: hidden; }
.final-glow { position: absolute; top: 50%; left: 50%; transform: translate(-50%,-50%); width: 400px; height: 200px; background: radial-gradient(ellipse, rgba(161,31,241,0.08) 0%, transparent 70%); pointer-events: none; }
.spd-final-inner h2 { font-family: var(--font-heading); font-size: clamp(1.5rem, 3vw, 2.1rem); margin-bottom: 12px; position: relative; z-index: 1; color: var(--sob-dark, #1c1c26); font-weight: 800; }
.spd-final-inner > p { color: var(--sob-gray, #6b6b76); font-size: 0.95rem; margin-bottom: 24px; position: relative; z-index: 1; }
.final-price { margin-bottom: 24px; position: relative; z-index: 1; display: flex; align-items: center; justify-content: center; gap: 12px; }
.final-price del { color: var(--sob-muted, #9494a2); font-size: 1.2rem; }
.final-price span { color: var(--sob-primary, #a11ff1); font-size: 2.2rem; font-weight: 800; font-family: var(--font-heading); }
.spd-final-btn { display: inline-flex; align-items: center; justify-content: center; gap: 10px; padding: 16px 44px; background: linear-gradient(135deg, var(--sob-primary, #a11ff1), var(--sob-primary-dark, #7c17c2)); color: #ffffff !important; font-weight: 700; font-size: 1.1rem; border-radius: 50px; text-decoration: none; transition: opacity 0.2s, box-shadow 0.3s, transform 0.2s; position: relative; z-index: 1; margin-bottom: 20px; box-sizing: border-box; }
.spd-final-btn:hover { opacity: 0.95; transform: translateY(-3px); box-shadow: 0 10px 32px rgba(161,31,241,0.4); color: #ffffff !important; }
.final-badges { display: flex; align-items: center; justify-content: center; gap: 24px; flex-wrap: wrap; font-size: 0.85rem; color: var(--sob-gray, #6b6b76); position: relative; z-index: 1; }

/* Related */
.products-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(220px, 1fr)); gap: 24px; }

/* ===== KEY BENEFITS ===== */
.spd-benefits-section { padding: 60px 0; background: #ffffff; text-align: center; }
.spd-benefits-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(260px, 1fr));
  gap: 20px;
  margin-top: 40px;
  text-align: left;
}
.benefit-card {
  display: flex;
  align-items: flex-start;
  gap: 16px;
  padding: 18px 22px;
  background: #ffffff;
  border: 1px solid var(--sob-border, #ececf3);
  border-radius: var(--radius-lg);
  transition: border-color 0.3s, transform 0.3s;
  box-shadow: 0 2px 10px rgba(0,0,0,0.03);
}
.benefit-card:hover {
  border-color: var(--sob-primary, #a11ff1);
  transform: translateY(-4px);
  box-shadow: 0 10px 25px rgba(161,31,241,0.1);
}
.benefit-check {
  flex-shrink: 0;
  width: 34px; height: 34px;
  background: linear-gradient(135deg, var(--sob-primary, #a11ff1), var(--sob-primary-dark, #7c17c2));
  color: #ffffff;
  font-weight: 900;
  font-size: 0.95rem;
  border-radius: 50%;
  display: flex; align-items: center; justify-content: center;
}
.benefit-card p {
  color: var(--sob-dark, #1c1c26);
  font-size: 0.93rem;
  line-height: 1.6;
  margin: 0;
}

/* ===== INFO CARDS ===== */
.spd-info-cards-section { padding: 60px 0; background: var(--sob-light, #f7f5fb); }
.spd-info-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
  gap: 24px;
  margin-top: 0;
}
.info-card {
  padding: 24px 28px;
  border-radius: var(--radius-lg);
  border: 1px solid var(--sob-border, #ececf3);
  background: #ffffff;
  box-shadow: 0 2px 10px rgba(0,0,0,0.03);
}
.info-card .ic-header {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-bottom: 14px;
}
.ic-icon { font-size: 1.5rem; flex-shrink: 0; }
.info-card .ic-header h3 {
  font-size: 1rem;
  font-family: var(--font-heading);
  margin: 0;
  font-weight: 700;
  color: var(--sob-dark, #1c1c26);
}
.info-card p {
  font-size: 0.88rem;
  color: var(--sob-gray, #6b6b76);
  line-height: 1.7;
  margin: 0;
}
.info-card--warning {
  border-color: rgba(245,158,11,0.4);
  background: #fffbeb;
}
.info-card--warning .ic-header h3 { color: #d97706; }
.info-card--storage {
  border-color: rgba(59,130,246,0.3);
  background: #eff6ff;
}
.info-card--storage .ic-header h3 { color: #2563eb; }
.info-card--auth {
  border-color: rgba(161,31,241,0.3);
  background: #faf5ff;
}
.info-card--auth .ic-header h3 { color: var(--sob-primary, #a11ff1); }
.info-card--skin {
  border-color: rgba(16,185,129,0.3);
  background: #f0fdf4;
}
.info-card--skin .ic-header h3 { color: #059669; }

/* ===== DISCLAIMER (Important Note) ===== */
.spd-disclaimer-section { padding: 40px 0; background: #ffffff; }
.spd-disclaimer-inner {
  display: flex;
  align-items: flex-start;
  gap: 20px;
  padding: 22px 28px;
  background: var(--sob-light, #f7f5fb);
  border: 1px solid var(--sob-border, #ececf3);
  border-left: 4px solid var(--sob-primary, #a11ff1);
  border-radius: var(--radius-lg);
  box-shadow: none;
}
.disclaimer-icon { font-size: 2rem; flex-shrink: 0; line-height: 1; }
.disclaimer-text-wrap { flex: 1; }
.spd-disclaimer-inner h4 {
  font-size: 0.95rem;
  color: var(--sob-primary, #a11ff1);
  margin-bottom: 8px;
  font-family: var(--font-heading);
  font-weight: 700;
  letter-spacing: 0.02em;
}
.spd-disclaimer-inner p {
  font-size: 0.88rem;
  color: var(--sob-gray, #6b6b76);
  line-height: 1.7;
  margin: 0;
}

/* ===========================
   RESPONSIVE — TABLET 1024px
   =========================== */
@media (max-width: 1024px) {
  /* Video/Image swap for Beauty Milk */
  .is-beauty-milk .spd-video-desktop-only { display: none !important; }
  .is-beauty-milk .spd-video-mobile-only { display: block !important; margin: 8px 0 16px 0 !important; }
  .is-beauty-milk .spd-video-mobile-only .spd-video-section { padding: 0 !important; background: transparent !important; margin: 0 !important; }
  .is-beauty-milk .spd-video-mobile-only .spd-product-video-wrap { margin-top: 0 !important; gap: 0 !important; }
  .is-beauty-milk .spd-video-mobile-only .spd-product-video-inner { padding: 6px !important; }
  .is-beauty-milk .spd-video-mobile-only .container { padding: 0 !important; max-width: 100% !important; }
  .is-beauty-milk .spd-video-mobile-only .spd-video-side { display: none !important; }
  .is-beauty-milk .spd-image-col { display: none !important; }

  /* For all other products: ALWAYS show product image gallery on mobile & tablet */
  .is-general-product .spd-image-col { display: block !important; width: 100% !important; }
  .is-general-product .spd-video-mobile-only { display: none !important; }
  .is-general-product .spd-video-desktop-only { display: block !important; }

  .spd-grid { grid-template-columns: 1fr; gap: 40px; }
  .spd-how-grid { grid-template-columns: repeat(2, 1fr); }
  .spd-usage-steps { grid-template-columns: repeat(2, 1fr); }
  .spd-refund-inner { flex-direction: column; text-align: center; padding: 32px; }
  .spd-refund-inner .refund-icon { font-size: 3rem; }
  .spd-product-video-wrap { grid-template-columns: 1fr; }
  .spd-video-side { display: grid; grid-template-columns: repeat(2, 1fr); gap: 16px; flex-direction: unset; }
  .vside-item { flex: unset; min-width: unset; }
  .vside-btn { grid-column: 1 / -1; width: 100%; margin-top: 0; }
}

/* ===========================
   RESPONSIVE — MOBILE 640px
   =========================== */
@media (max-width: 640px) {
  .spd-hero { padding: 20px 0 28px; }
  .spd-video-section,
  .spd-how-section,
  .spd-timeline-section,
  .spd-usage-section,
  .spd-benefits-section,
  .spd-reviews-section,
  .spd-final-order { padding: 36px 0; }
  .spd-info-cards-section { padding: 36px 0; }
  .spd-refund-section { padding: 28px 0; }
  .spd-disclaimer-section { padding: 20px 0; }

  /* Gallery */
  .spd-main-img { height: 290px; }
  .gallery-arrow { width: 34px; height: 34px; font-size: 1.3rem; }
  .spd-thumb { width: 56px; height: 56px; }
  .lb-arrow { width: 42px; height: 42px; font-size: 1.6rem; }
  .lb-arrow--prev { left: 8px; }
  .lb-arrow--next { right: 8px; }

  /* Guarantee badge */
  .spd-guarantee-badge { flex-wrap: wrap; gap: 8px; padding: 10px 14px; font-size: 0.76rem; }
  .gb-divider { display: none; }
  .spd-thumbs-row { overflow-x: auto; flex-wrap: nowrap; padding-bottom: 8px; -webkit-overflow-scrolling: touch; }

  /* Title & Tagline strictly fit */
  .spd-title {
    font-size: clamp(1.1rem, 4.5vw, 1.45rem);
    line-height: 1.25;
    margin-bottom: 10px;
  }
  .spd-tagline {
    font-size: 0.84rem;
    line-height: 1.4;
    padding: 8px 12px;
    margin-bottom: 14px;
    -webkit-line-clamp: 2;
  }

  /* Prices & Buttons */
  .spd-current-price { font-size: 1.8rem; }
  .spd-order-btn { font-size: 1rem; padding: 14px; }
  .spd-buynow-btn { font-size: 0.9rem; padding: 12px; }

  /* Grids → 1 column */
  .spd-how-grid { grid-template-columns: 1fr; }
  .spd-usage-steps { grid-template-columns: 1fr; }
  .spd-benefits-grid { grid-template-columns: 1fr; }
  .spd-info-grid { grid-template-columns: 1fr; }
  .products-grid { grid-template-columns: repeat(2, 1fr); gap: 12px; }

  /* Section headings */
  .section-title { font-size: clamp(1.25rem, 4.5vw, 1.65rem); }

  /* Timeline */
  .spd-timeline { flex-direction: column !important; align-items: center !important; }
  .tl-connector { width: 2px !important; height: 38px !important; background: linear-gradient(180deg, rgba(201,169,110,0.3), rgba(201,169,110,0.7)) !important; margin: 8px 0 !important; }
  .tl-step { max-width: 280px !important; }
  .tl-bubble-1 { width: 62px !important; height: 62px !important; font-size: 0.82rem !important; }
  .tl-bubble-2 { width: 84px !important; height: 84px !important; font-size: 1rem !important; }
  .tl-bubble-3 { width: 108px !important; height: 108px !important; font-size: 1.2rem !important; }

  /* How section */
  .spd-combined { flex-direction: column; text-align: center; padding: 20px; }
  .how-card { padding: 24px 18px; }

  /* Video side */
  .spd-video-side { display: flex; flex-direction: column; }
  .vside-item { min-width: unset; flex: unset; }
  .vside-btn { width: 100%; grid-column: unset; }

  /* Refund */
  .spd-refund-inner { flex-direction: column; text-align: center; padding: 24px 16px; }
  .refund-icon { font-size: 2.5rem; }
  .refund-text h2 { font-size: 1.25rem; }

  /* Final CTA */
  .spd-final-inner { padding: 36px 16px; border-radius: 16px; }
  .spd-final-btn { padding: 14px 24px; font-size: 0.95rem; width: 100%; max-width: 320px; box-sizing: border-box; }
  .final-badges { gap: 10px; font-size: 0.78rem; }
  .final-price span { font-size: 1.8rem; }
  .final-price del { font-size: 1rem; }

  /* Customer Reviews */
  .spd-video-reviews { grid-template-columns: 1fr; max-width: 340px; margin-left: auto; margin-right: auto; }

  /* Disclaimer */
  .spd-disclaimer-inner { flex-direction: column; gap: 12px; padding: 18px 16px; }
  .disclaimer-icon { font-size: 1.6rem; }

  /* Info cards & benefits */
  .info-card { padding: 18px 16px; }
  .benefit-card { padding: 16px; }
  .usage-step { padding: 20px 16px; }
}

/* ===========================
   RESPONSIVE — SMALL 400px
   =========================== */
@media (max-width: 400px) {
  .products-grid { grid-template-columns: 1fr; }
  .trust-badge { min-width: 68px; font-size: 0.72rem; padding: 6px 8px; }
  .spd-order-btn { font-size: 0.92rem; padding: 13px; }
  .spd-current-price { font-size: 1.6rem; }
  .spd-old-price { font-size: 0.95rem; }
  .spd-ingr-row { gap: 6px; }
  .ingr-chip { font-size: 0.75rem; padding: 5px 10px; }
  .spd-delivery { padding: 12px; }
  .dlv-item { font-size: 0.8rem; }
  .spd-guarantee-badge { font-size: 0.72rem; }
  .spd-guarantee-badge strong { font-size: 0.82rem; }
  .tl-bubble { width: 68px; height: 68px; font-size: 0.8rem; }
  .gold-badge { font-size: 0.7rem; padding: 4px 12px; }
  .vr-label { font-size: 0.78rem; }
  .spd-main-img { height: 250px; }
}

/* ===========================
   DIRECT CHECKOUT STYLES (LIGHT LUXURY GLOWRIA)
   =========================== */
.spd-checkout-section {
  background: var(--sob-light, #f7f5fb) !important;
  padding: 60px 0;
  width: 100%;
}

.spd-checkout-container {
  max-width: 820px !important;
  margin: 0 auto !important;
  background: #ffffff !important;
  padding: 34px !important;
  border-radius: 16px !important;
  border: 1px solid var(--sob-border, #ececf3) !important;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.06) !important;
  box-sizing: border-box !important;
}

.spd-checkout-title {
  margin-bottom: 24px !important;
  font-size: 1.6rem !important;
  text-align: center !important;
  color: #1c1c26 !important;
}

.spd-checkout-section .woocommerce,
.spd-checkout-section form.checkout,
.spd-checkout-section .col2-set,
.spd-checkout-section #customer_details,
.spd-checkout-section #order_review_heading,
.spd-checkout-section #order_review,
.spd-checkout-section .woocommerce-checkout-review-order,
.spd-checkout-section .woocommerce-checkout-review-order-table,
.spd-checkout-section #payment {
  width: 100% !important;
  max-width: 100% !important;
  float: none !important;
  clear: both !important;
  margin-left: 0 !important;
  margin-right: 0 !important;
  box-sizing: border-box !important;
}

.spd-checkout-section .col2-set .col-1,
.spd-checkout-section .col2-set .col-2 {
  width: 100% !important;
  max-width: 100% !important;
  float: none !important;
  padding: 0 !important;
  margin: 0 0 16px 0 !important;
  box-sizing: border-box !important;
}

.spd-checkout-section .woocommerce form.checkout label {
  color: #2d2d3a !important;
  font-size: 0.9rem !important;
  font-weight: 600 !important;
  margin-bottom: 6px !important;
  display: block !important;
}

.spd-checkout-section .woocommerce form.checkout input[type="text"], 
.spd-checkout-section .woocommerce form.checkout input[type="email"], 
.spd-checkout-section .woocommerce form.checkout input[type="tel"], 
.spd-checkout-section .woocommerce form.checkout textarea, 
.spd-checkout-section .woocommerce form.checkout select {
  background: #ffffff !important;
  color: #1c1c26 !important;
  border: 1px solid #ececf3 !important;
  padding: 12px 14px !important;
  border-radius: 8px !important;
  width: 100% !important;
  transition: all 0.25s ease !important;
  font-size: 0.95rem !important;
  box-sizing: border-box !important;
}

.spd-checkout-section .woocommerce form.checkout input:focus, 
.spd-checkout-section .woocommerce form.checkout textarea:focus {
  border-color: #a11ff1 !important;
  box-shadow: 0 0 0 3px rgba(161, 31, 241, 0.12) !important;
  outline: none !important;
}

.spd-checkout-section .woocommerce-checkout #payment {
  background: #f7f5fb !important;
  border-radius: 12px !important;
  padding: 20px !important;
  border: 1px solid #ececf3 !important;
  margin-top: 20px !important;
}

.spd-checkout-section .woocommerce-checkout #payment ul.payment_methods {
  border-bottom: 1px solid #ececf3 !important;
  padding-bottom: 16px !important;
  list-style: none !important;
  padding-left: 0 !important;
}

.spd-checkout-section .woocommerce-checkout #payment div.payment_box {
  background: #ffffff !important;
  color: #555555 !important;
  border-radius: 8px !important;
  border: 1px solid #ececf3 !important;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.04) !important;
  font-size: 0.9rem !important;
  padding: 12px 14px !important;
}

.spd-checkout-section .woocommerce table.shop_table {
  border: 1px solid #ececf3 !important;
  border-radius: 8px !important;
  width: 100% !important;
  border-collapse: collapse !important;
  margin-bottom: 24px !important;
  background: #ffffff !important;
}

.spd-checkout-section .woocommerce table.shop_table th,
.spd-checkout-section .woocommerce table.shop_table td {
  border-top: 1px solid #ececf3 !important;
  color: #1c1c26 !important;
  padding: 12px 14px !important;
  box-sizing: border-box !important;
}

.spd-checkout-section .woocommerce table.shop_table thead th {
  background: #f7f5fb !important;
  color: #6b6b76 !important;
  text-transform: uppercase !important;
  font-size: 0.82rem !important;
  letter-spacing: 0.5px !important;
  font-weight: 700 !important;
}

.spd-checkout-section .woocommerce table.shop_table tfoot th,
.spd-checkout-section .woocommerce table.shop_table tfoot td {
  border-top: 2px solid #ececf3 !important;
}

/* PLACE ORDER BUTTON DEFINITIVE VIBRANT FIX */
#place_order,
.woocommerce #payment #place_order,
.spd-checkout-section #place_order,
.spd-checkout-section .woocommerce-checkout #payment #place_order {
  display: block !important;
  width: 100% !important;
  padding: 16px 28px !important;
  background: linear-gradient(135deg, #a11ff1, #7c17c2) !important;
  color: #ffffff !important;
  -webkit-text-fill-color: #ffffff !important;
  border-radius: 50px !important;
  font-weight: 700 !important;
  font-size: 1.1rem !important;
  border: none !important;
  cursor: pointer !important;
  margin: 20px 0 10px 0 !important;
  box-shadow: 0 8px 24px rgba(161, 31, 241, 0.35) !important;
  font-family: var(--font-body), 'Poppins', sans-serif !important;
  transition: all 0.25s ease !important;
  text-align: center !important;
  opacity: 1 !important;
  visibility: visible !important;
}

#place_order:hover,
.woocommerce #payment #place_order:hover,
.spd-checkout-section #place_order:hover,
.spd-checkout-section .woocommerce-checkout #payment #place_order:hover {
  background: linear-gradient(135deg, #8a15cf, #6710a3) !important;
  transform: translateY(-2px) !important;
  box-shadow: 0 12px 30px rgba(161, 31, 241, 0.5) !important;
  color: #ffffff !important;
  -webkit-text-fill-color: #ffffff !important;
#place_order *,
.woocommerce #payment #place_order *,
.spd-checkout-section #place_order *,
.spd-checkout-section .woocommerce-checkout #payment #place_order * {
  color: #ffffff !important;
  -webkit-text-fill-color: #ffffff !important;
}

/* Quantity +/- and Remove in review table */
.sob-checkout-item-actions {
  display: inline-flex !important;
  align-items: center !important;
  gap: 10px !important;
  margin-top: 6px !important;
  vertical-align: middle !important;
}

.sob-checkout-qty {
  display: inline-flex !important;
  align-items: center !important;
  gap: 6px !important;
  background: #f3e5fd !important;
  border: 1px solid #d8b4fe !important;
  border-radius: 6px !important;
  padding: 2px 6px !important;
}

.sob-qty-btn {
  background: transparent !important;
  border: none !important;
  color: #7c17c2 !important;
  font-weight: 700 !important;
  font-size: 16px !important;
  cursor: pointer !important;
  width: 22px !important;
  height: 22px !important;
  display: inline-flex !important;
  align-items: center !important;
  justify-content: center !important;
  line-height: 1 !important;
  user-select: none !important;
  padding: 0 !important;
  border-radius: 4px !important;
  transition: all 0.2s ease !important;
}

.sob-qty-btn:hover {
  background: #a11ff1 !important;
  color: #ffffff !important;
}

.sob-qty-val {
  font-weight: 700 !important;
  min-width: 18px !important;
  text-align: center !important;
  font-size: 13.5px !important;
  color: #1c1c26 !important;
  -webkit-text-fill-color: #1c1c26 !important;
}

.sob-checkout-remove {
  color: #ef4444 !important;
  font-size: 12px !important;
  font-weight: 500 !important;
  text-decoration: underline !important;
  line-height: 1 !important;
  cursor: pointer !important;
}

.sob-checkout-remove:hover {
  color: #b91c1c !important;
}

/* Mobile Responsiveness for Checkout */
@media (max-width: 768px) {
  .spd-checkout-section {
    padding: 24px 0 95px 0 !important; /* Extra bottom padding so mobile bottom navbar doesn't cover button */
  }

  .spd-checkout-container {
    padding: 18px 12px !important;
    border-radius: 12px !important;
    width: calc(100% - 20px) !important;
    max-width: calc(100% - 20px) !important;
    margin: 0 auto !important;
    box-sizing: border-box !important;
  }

  .spd-checkout-section #customer_details,
  .spd-checkout-section #order_review,
  .spd-checkout-section .woocommerce-checkout-review-order {
    padding: 0 !important;
    width: 100% !important;
    float: none !important;
    clear: both !important;
  }

  .spd-checkout-title {
    font-size: 1.25rem !important;
    margin-bottom: 16px !important;
  }

  .spd-checkout-section .woocommerce table.shop_table th,
  .spd-checkout-section .woocommerce table.shop_table td {
    padding: 10px 8px !important;
    font-size: 13.5px !important;
  }

  .spd-checkout-section .woocommerce table.shop_table td.product-total {
    text-align: right !important;
    white-space: nowrap !important;
  }

  .spd-checkout-section .woocommerce-checkout #payment {
    padding: 14px 10px !important;
  }

  #place_order,
  .woocommerce #payment #place_order,
  .spd-checkout-section #place_order,
  .spd-checkout-section .woocommerce-checkout #payment #place_order {
    padding: 15px 20px !important;
    font-size: 1rem !important;
  }
}
</style>

<script>
let spdQty = 1;
function spd_changeQty(delta) {
    spdQty = Math.max(1, Math.min(10, spdQty + delta));
    const d = document.getElementById('qty-display');
    if (d) d.textContent = spdQty;
    
    // Update hidden inputs for direct checkout forms
    document.querySelectorAll('.spd-qty-input').forEach(function(el) {
        el.value = spdQty;
    });
    
    // Update Add to Cart button link
    const cartBtn = document.getElementById('spd-cart-btn');
    if (cartBtn) cartBtn.href = cartBtn.href.replace(/quantity=\d+/, 'quantity=' + spdQty);
}

// ===== PREMIUM GALLERY CONTROLLER =====
var spdGallery = (function() {
    var current = 0;
    var images  = typeof spdGalleryImages !== 'undefined' ? spdGalleryImages : [];
    var total   = images.length;

    function setMain(idx) {
        if (!images[idx]) return;
        current = idx;
        var mainImg = document.getElementById('spd-main-img');
        var counter = document.getElementById('gallery-counter');
        var lbCounter = document.getElementById('lb-counter');
        if (mainImg) {
            mainImg.style.opacity = '0.5';
            mainImg.src = images[idx].large;
            mainImg.alt = images[idx].alt || '';
            mainImg.onload = function() { mainImg.style.opacity = '1'; };
        }
        if (counter) counter.textContent = (idx + 1) + ' / ' + total;
        // Update thumbs
        var thumbs = document.querySelectorAll('.spd-thumb');
        thumbs.forEach(function(t, i) {
            t.classList.toggle('active', i === idx);
        });
        // Scroll thumb into view
        if (thumbs[idx]) thumbs[idx].scrollIntoView({ behavior: 'smooth', block: 'nearest', inline: 'center' });
        // Update lightbox counter
        if (lbCounter) lbCounter.textContent = (idx + 1) + ' / ' + total;
    }

    function prev() { setMain((current - 1 + total) % total); }
    function next() { setMain((current + 1) % total); }

    function goTo(idx) { setMain(idx); }

    function openLightbox(idx) {
        var lb = document.getElementById('spd-lightbox');
        var lbImg = document.getElementById('lb-img');
        var lbCounter = document.getElementById('lb-counter');
        if (!lb || !images[idx]) return;
        current = idx;
        lbImg.src = images[idx].full || images[idx].large;
        lbImg.alt = images[idx].alt || '';
        if (lbCounter) lbCounter.textContent = (idx + 1) + ' / ' + total;
        lb.classList.add('open');
        document.body.style.overflow = 'hidden';
    }

    function closeLightbox() {
        var lb = document.getElementById('spd-lightbox');
        if (lb) lb.classList.remove('open');
        document.body.style.overflow = '';
    }

    function lbPrev() {
        var newIdx = (current - 1 + total) % total;
        openLightbox(newIdx);
    }

    function lbNext() {
        var newIdx = (current + 1) % total;
        openLightbox(newIdx);
    }

    // Keyboard navigation
    document.addEventListener('keydown', function(e) {
        var lb = document.getElementById('spd-lightbox');
        if (!lb || !lb.classList.contains('open')) return;
        if (e.key === 'Escape') closeLightbox();
        if (e.key === 'ArrowLeft') lbPrev();
        if (e.key === 'ArrowRight') lbNext();
    });

    // Touch/Swipe support for gallery
    var touchStartX = 0;
    var galEl = document.getElementById('spd-gallery');
    if (galEl) {
        galEl.addEventListener('touchstart', function(e) { touchStartX = e.touches[0].clientX; }, { passive: true });
        galEl.addEventListener('touchend', function(e) {
            var diff = touchStartX - e.changedTouches[0].clientX;
            if (Math.abs(diff) > 50) { if (diff > 0) next(); else prev(); }
        }, { passive: true });
    }

    return { prev: prev, next: next, goTo: goTo, openLightbox: openLightbox, closeLightbox: closeLightbox, lbPrev: lbPrev, lbNext: lbNext };
})();
</script>

<?php get_footer(); ?>
